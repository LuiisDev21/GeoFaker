from setuptools import setup, find_packages

if __name__ == '__main__':

    setup(
        name='XetMap',
        description='Libreria que te proporciona direcciones reales de Estados Unidos',
        license='MIT',
        url='https://github.com/MrXetwy21/XetMap',
        version='1.0',
        author='MrXetwy21',
        author_email='Xetwy21@gmail.com',
        packages=find_packages(),
        long_description=open('README.md', encoding='utf-8').read(),
        long_description_content_type='text/markdown',
        classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Environment :: Console",
        "Intended Audience :: Developers",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.6",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Software Development :: Testing",
        "Topic :: Utilities"
        ],
        install_requires=["json", "random", "names", "os"],
        python_requires='>=3.10',
        
    )

